Instrument Chord
=====

Render music chords on a guitar and piano

* Requires https://github.com/xpika/music-diatonic

Example:

```
*Main> putStrLn (renderChords  (C , majorChord  ))
----x-
--x---
-x----
------
       
----x-
--x---
-x---x
------
       
----x-
--x---
xx----
------
       
----x-
--x---
xx---x
------
```
